import React from "react";
import { BrowserRouter as Router,Switch,Route,Link} from "react-router-dom"
import Navbar from "../components/navbar/Navbar"
import Sidebar from "../components/sidebar/Sidebar"
import Requests from "../components/Requests/Requests"

function Request() {
    return (
        <div className="App">
            <Sidebar/>
            <Navbar/>
            <Requests/>
        </div>
      );
    }

export default Request
