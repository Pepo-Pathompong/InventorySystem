import React from "react";
import { BrowserRouter as Router,Switch,Route,Link} from "react-router-dom"
import Navbar from "../components/navbar/Navbar"
import Sidebar from "../components/sidebar/Sidebar"
import Payrolls from "../components/Payrolls/Payrolls"

function Payroll() {
    return (
        <div className="App">
            <Sidebar/>
            <Navbar/>
            <Payrolls/>
        </div>
      );
    }

export default Payroll
