import React from "react";
import { BrowserRouter as Router,Switch,Route,Link} from "react-router-dom";
import Navbar from "../components/navbar/Navbar";
import Sidebar from "../components/sidebar/Sidebar";
import House from "../components/Warehouse/House"

function Warehouse() {
    return (
        <div className="App">
            <Sidebar/>
            <Navbar/>
            <House/>
        </div>
      );
    }

export default Warehouse
