import React from "react";
import { BrowserRouter as Router,Switch,Route,Link} from "react-router-dom";
import Navbar from "../components/navbar/Navbar";
import Sidebar from "../components/sidebar/Sidebar";
import Main from "../components/main/Main";

function Dashboard() {
    return (
        <div className="App">
            <Sidebar/>
            <Navbar/>
            <Main/>
        </div>
      );
    }

export default Dashboard
