import React from "react";
import { BrowserRouter as Router,Switch,Route,Link} from "react-router-dom"
import Navbar from "../components/navbar/Navbar"
import Sidebar from "../components/sidebar/Sidebar"
import Regis from "../components/Register_name/Regis"

function Register() {
    return (
        <div className="App">
            <Regis/>
        </div>
      );
    }

export default Register
