import React from "react";
import { BrowserRouter as Router,Switch,Route,Link} from "react-router-dom"
import Navbar from "../components/navbar/Navbar"
import Sidebar from "../components/sidebar/Sidebar"
import CManage from "../components/main/CManage"

function Company() {
    return (
        <div className="App">
            <Sidebar/>
            <Navbar/>
            <CManage/>
        </div>
      );
    }

export default Company
