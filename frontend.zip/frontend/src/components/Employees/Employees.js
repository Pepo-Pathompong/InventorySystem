import React from 'react'
import "./Employees.css"

function Employees() {
    return (
        <div >
        <button class ="Add">Additions</button>
         <table class="content-table">
            <thead>
                <tr>
                  
                    <th>Rank</th>
                    <th>Name</th>
                    <th>Points</th>
                    <th>Email</th>
                    <th>Active</th>
                </tr>
            </thead>
            <tbody>
                <tr >
                    <td>1</td>
                    <td>Anchor</td>
                    <td>88,110</td>
                    <td>Anchor_Valid@hotmail.com</td>
                    <td> <button class ="edit">Edit</button> <button class ="delete">Delete</button></td>
                </tr>
                <tr class="active-row" >
                    <td>2</td>
                    <td>Sally</td>
                    <td>72,400</td>
                    <td>Sally@hotmail.com</td>
                    <td> <button class ="edit">Edit</button> <button class ="delete">Delete</button></td>
                </tr>
                <tr>
                    <td>3</td>
                    <td>Nick</td>
                    <td>52,300</td>
                    <td>Nick_001@hotmail.com</td>
                    <td> <button class ="edit">Edit</button> <button class ="delete">Delete</button></td>
                </tr>
                <tr>
                    <td>4</td>
                    <td>Munuis</td>
                    <td>60,100</td>
                    <td>Munuis@hotmail.com</td>
                    <td> <button class ="edit">Edit</button> <button class ="delete">Delete</button></td>
                </tr>
                <tr>
                    <td>4</td>
                    <td>Irsin</td>
                    <td>60,100</td>
                    <td>Irsin_M@hotmail.com</td>
                    <td> <button class ="edit">Edit</button> <button class ="delete">Delete</button></td>
                </tr>
                <tr>
                    <td>5</td>
                    <td>Panis</td>
                    <td>65,100</td>
                    <td>Panis200@hotmail.com</td>
                    <td> <button class ="edit">Edit</button> <button class ="delete">Delete</button></td>
                </tr>
            </tbody>
         </table>
        </div>
    )
}

export default Employees
