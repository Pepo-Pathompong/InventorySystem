import React from 'react'
// import { Link } from 'react-router-dom';
import axios from '../../axios'
import FormData from 'form-data'
import {useState} from 'react'
import "./Regis.css"


function Regis() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [email, setEmail] = useState("");

  const submitSignup = (event) => {
    event.preventDefault();
    const formData = new FormData();
    formData.append("username", username);
    formData.append("password", password);
    formData.append("email", email);
    console.log(username,password,email)

    axios.post("/SignupServlet",formData).then((res) => {
      window.location.href = "/";
    }).catch((error) =>{
      alert(error);
    });
  };

    return (
        <div className = "regis">
<div id="login-box">
  <div class="left">
    <h1>Sign up</h1>
    
    <input 
        type="text"
        value={username}
        onChange={(e) => setUsername(e.target.value)}
        placeholder="Username"
    />

    <input 
        type="text"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        placeholder="Email" 
    />

    <input 
        type="text"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        placeholder="Password"
    />

    <input
         type="text"
         value={password}
         onChange={(e) => setPassword(e.target.value)}
         placeholder="Check Password"
     />

    <input onClick = {submitSignup}
        type="submit"
        name="signup_submit" 
        value="Sign me up" 
    />

  </div>

    <div class="right">
      <span class="loginwith">Sign in with<br />social network</span>
      <button class="social-signin facebook">Log in with facebook</button>
      <button class="social-signin twitter">Log in with Twitter</button>
      <button class="social-signin google">Log in with Google+</button>
   </div>

  <div class="or">OR</div>
</div>
        </div>
    )
}

export default Regis
