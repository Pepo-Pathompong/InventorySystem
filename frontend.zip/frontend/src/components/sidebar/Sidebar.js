import React from 'react'
import "./Sidebar.css"
import {Link} from "react-router-dom";

function Sidebar() {
    return (
      <div id="sidebar">
      <div class="sidebar__title">
        <div class="sidebar__img">
          <img src="assets/boy.png" alt="boy" />
          <h1>Profile Management</h1>
        </div>
        <i
          onclick="closeSidebar()"
          class="fa fa-times"
          id="sidebarIcon"
          aria-hidden="true"
        ></i>
      </div>

      <div class="sidebar__menu">
        <div class="sidebar__link active_menu_link">
          <i class="fa fa-home"></i>
          <a href="#">Dashboard</a>
        </div>
        <h2>Management</h2>
       
        <Link to = "/Company" >
        <div class="sidebar__link">
          <i class="fa fa-building-o"></i>
          <a href="#">Company Management</a>
        </div>
        </Link>
        <Link to = "/Employee" >
        <div class="sidebar__link">
          <i class="fa fa-wrench"></i>
          <a href="#">Employee Management</a>
        </div>
        </Link>
        <Link to = "/Warehouse" >
        <div class="sidebar__link">
          <i class="fa fa-archive"></i>
          <a href="#">Warehouse</a>
        </div>
        </Link>
        
        <h2>LEAVE</h2>
        <Link to = "/Request" >
        <div class="sidebar__link">
          <i class="fa fa-question"></i>
          <a href="#">Requests</a>
        </div>
        </Link>
        <Link to = "/Apply" >
        <div class="sidebar__link">
          <i class="fa fa-files-o"></i>
          <a href="#">Apply for leave</a>
        </div>
        </Link>
       
        <h2>PAYROLL</h2>
        <Link to = "/Payroll" >
        <div class="sidebar__link">
          <i class="fa fa-money"></i>
          <a href="#">Payroll</a>
        </div>
        </Link>
        
        <Link to = "/" >
        <div class="sidebar__logout">
          <i class="fa fa-power-off"></i>
          <a href="#">Log out</a>
        </div>
        </Link>
      </div>
    </div>
    
    );
};


export default Sidebar;
