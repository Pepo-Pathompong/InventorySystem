import React from 'react'
import { Link } from 'react-router-dom';
import "./Login.css";  
 

function LoginPage() {
    return (
        
        <div className= "login-wallpaper">  
            <form class="box" action="Login.html" method="post">
                    <h1>Login</h1>
                    <input type="text" name="" placeholder="Username"/>
                    <input type="password" name="" placeholder="Password"/>
         <Link to = "/Dashboard" >
                 <a href>
                 <input type="submit" name="" value="Login"/>
                 </a>
         </Link>
         <Link to = "/Register" >
                 <a href>
                 <input type="submit" name="" value="Register"/>
                 </a>
          </Link>
        </form>
    </div> 
    
    )
}

export default LoginPage
