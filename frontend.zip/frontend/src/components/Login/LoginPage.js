import React from 'react'
import { Link } from 'react-router-dom';
import axios from '../../axios'
// import FormData from 'form-data'
import "./Login.css";  
import {useState} from 'react'
import qs from 'qs'


function LoginPage() {
    const [username, setUsername] = useState("");
    const [password, setPassword] = useState("");
    

    const submitSignin = (event) => {
        event.preventDefault();
        // const formData = new FormData();
        // formData.append("username", username);
        // formData.append("password", password);
        // formData.append("email", "@email");
        // console.log(username,password)

        axios.post("/SignInServlet",qs.stringify({
          username,password
        })).then((res) => {
          window.location.href = "/Dashboard";
        }).catch((error) =>{
          console.log(error)
          // alert(error.response.data.message);
        });
    
      };

    return (
        <div className= "login-wallpaper">  
            <form class="box" action="Login.html" method="post">
                    <h1>Login</h1>
                    <input
                        type="text"
                        value={username}
                        onChange={(e) => setUsername(e.target.value)}
                        placeholder="Username"
                        />
                    <input
                        type="text"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder="Password"
                        />
        
                 <a href onClick={submitSignin}>
                 <input type="submit" name="" value="Login"/>
                 </a>
                  <Link to ="/Register">
                 <a href >
                 <input type="submit" name="" value="Register"/>
                 </a>
                  </Link>
        </form>
    </div> 
    
    )
}

export default LoginPage
