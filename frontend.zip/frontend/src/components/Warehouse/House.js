import React from 'react'
import Popup from  "../Popup/Popup"
import axios from '../../axios'
import FormData from 'form-data'
import {useState} from 'react'
import "./House.css"
import qs from 'qs'

function House() {
  const [busshopPopup, setBusshopPopup] = useState(false);
  const [addshop1Popup, setAddshop1Popup] = useState(false);
  const [addshop2Popup, setAddshop2Popup] = useState(false);
  const [addshop3Popup, setAddshop3Popup] = useState(false);
  const [addshop4Popup, setAddshop4Popup] = useState(false);
  const [addshop5Popup, setAddshop5Popup] = useState(false);
  const [addshop6Popup, setAddshop6Popup] = useState(false);
  const [addshop7Popup, setAddshop7Popup] = useState(false);

  const [product, setProduct] = useState("");
  const [type, setType] = useState("");
  const [amount, setAmount] = useState("");
  const [date, setDate] = useState("");

  const clickView = (event) => {
    event.preventDefault();
    const formData = new FormData();
    formData.append("product", product);
    formData.append("type", type);
    formData.append("amount", amount);
    formData.append("date", date);
    console.log(product,type,amount,date)

    axios.post("/TransactionServlet",formData).then((res) => {
      window.location.href = "/Inventorys";
    }).catch((error) =>{
      alert(error);
    });
  };

    return (
        <div class="contain"> 
            <header class="Warehouse">
            <h4 class="logo">WAREHOUSE</h4>
            </header>
            <section class="intro">
            <div class="column">
                <h3>STOCK PRODUCT</h3>
                <img src="https://cf.shopee.co.th/file/3e5db1422320f0ca3091256bd91656bb" alt="" class="profile"/> </div>
            <div class="column">
                <p>Buying a warehouse, we do not need permission or consent from anyone. If you want to change the warehouse, you can do it. </p>
                <p>To take advantage of their own assets Like a real estate investment And have the opportunity to add value over time When you want to expand your business You can use the assets here to apply for bank loans to invest in expanding your business.</p>
            </div>
        </section>
        <div class="gallery">
          <div class="thumbnail"> <a href="#"><img src="https://cf.shopee.co.th/file/1db74637819488c9f4be0d0803d6844a" alt="" width="2000" class="cards"/></a>
            <h4>PEACH OOLONG (100)</h4>
            <p class="tag">M-808 perfume 80 ml. Available in 5 fragrances, fruity scents.</p>
            <p class="text_column">Eau de Parfum</p>
            <button onClick = {()=> setBusshopPopup (true)}>Add Now</button>
            <Popup trigger = {busshopPopup} setTrigger = {setBusshopPopup}>
            <form>
                  <label>Product</label><br/>
                    <select  type="text"
                      value={product}
                      onChange={(e) => setProduct(e.target.value)}
                      placeholder="Product">
                      <option>100</option>
                    </select>
                  <br/>

                 <label>Type</label><br/>
                   <select  type="text"
                      value={type}
                      onChange={(e) => setType(e.target.value)}
                      placeholder="Type">
                    <option>Eau de Parfum</option>
                  </select>
               <br/>

                <label>Amount</label><br/>
                    <input  type="text"
                      value={amount}
                      onChange={(e) => setAmount(e.target.value)}
                      placeholder="Amount"/>
                 <br/>

                 <label>Date</label><br/>
                    <input  type="date"
                      value={date}
                      onChange={(e) => setDate(e.target.value)}
                      placeholder="Date"/>
                  <br/>
                    <button onClick = {clickView}>Confirm</button>
                </form>
            </Popup>
          </div>
          <div class="thumbnail"> <a href="#"><img src="https://cf.shopee.co.th/file/fa8bfa7072b553114dc38dee44bad277" alt="" width="2000" class="cards"/></a>
            <h4>Midnight (101)</h4>
            <p class="tag">Midnight Fantasy Perfume Spray 35ml Suitable for teenagers.</p>
            <p class="text_column">Eau de Parfum</p>
            <button onClick = {()=> setAddshop1Popup (true)}>Add Now</button>
            <Popup trigger = {addshop1Popup} setTrigger = {setAddshop1Popup}>
            <form>
                    <label>Product</label><br/>
                    <select><option>101</option></select><br/>
                    <label>Type</label><br/>
                    <select><option>Eau de Parfum</option></select><br/>
                    <label>Amount</label><br/>
                    <input type="text" placeholder="Amount"/><br/>
                    <label>Date</label><br/>
                    <input type="date" placeholder="Date"/><br/>
                    <button>Confirm</button>
                </form>
            </Popup>
          </div>
          <div class="thumbnail"> <a href="#"><img src="https://cf.shopee.co.th/file/dbe0b9212c05882dba3867e12875694b" alt="" width="2000" class="cards"/></a>
            <h4>Midnight Fantasy (102)</h4>
            <p class="tag">The smell is also very popular evergreen available for teens ages.</p>
            <p class="text_column">Eau de Parfum</p>
            <button onClick = {()=> setAddshop2Popup (true)}>Add Now</button>
            <Popup trigger = {addshop2Popup} setTrigger = {setAddshop2Popup}>
            <form>
                    <label>Product</label><br/>
                    <select><option>102</option></select><br/>
                    <label>Type</label><br/>
                    <select><option>Eau de Parfum</option></select><br/>
                    <label>Amount</label><br/>
                    <input type="text" placeholder="Amount"/><br/>
                    <label>Date</label><br/>
                    <input type="date" placeholder="Date"/><br/>
                    <button>Confirm</button>
                </form>
            </Popup>
          </div>
          <div class="thumbnail"> <a href="#"><img src="https://cf.shopee.co.th/file/2f47f4b3037899b20a650d908a76bcd3" alt="" width="2000" class="cards"/></a>
            <h4>Shimang (103)</h4>
            <p class="tag">Shimang Long-lasting peach scent water, 50 ml.</p>
            <p class="text_column">Eau de Parfum.</p>
            <button onClick = {()=> setAddshop3Popup (true)}>Add Now</button>
            <Popup trigger = {addshop3Popup} setTrigger = {setAddshop3Popup}>
            <form>
                    <label>Product</label><br/>
                    <select><option>103</option></select><br/>
                    <label>Type</label><br/>
                    <select><option>Eau de Parfum</option></select><br/>
                    <label>Amount</label><br/>
                    <input type="text" placeholder="Amount"/><br/>
                    <label>Date</label><br/>
                    <input type="date" placeholder="Date"/><br/>
                    <button>Confirm</button>
                </form>
            </Popup>
          </div>
        </div>
        <div class="gallery">
          <div class="thumbnail"> <a href="#"><img src="https://cf.shopee.co.th/file/35f091a9c34396d6e50b3832c3dc46b1" alt="" width="2000" class="cards"/></a>
            <h4>Shimang (104)</h4>
            <p class="tag">Shimang Long-lasting peach scent water, 50 ml.</p>
            <p class="text_column">Eau de Parfum</p>
            <button onClick = {()=> setAddshop4Popup (true)}>Add Now</button>
            <Popup trigger = {addshop4Popup} setTrigger = {setAddshop4Popup}>
            <form>
                    <label>Product</label><br/>
                    <select><option>104</option></select><br/>
                    <label>Type</label><br/>
                    <select><option>Eau de Parfum</option></select><br/>
                    <label>Amount</label><br/>
                    <input type="text" placeholder="Amount"/><br/>
                    <label>Date</label><br/>
                    <input type="date" placeholder="Date"/><br/>
                    <button>Confirm</button>
                </form>
            </Popup>
          </div>
          <div class="thumbnail"> <a href="#"><img src="https://cf.shopee.co.th/file/620de08772fe752680a2b35b4a038133" alt="" width="2000" class="cards"/></a>
            <h4>Shimang (105)</h4>
            <p class="tag">Shimang Long-lasting peach scent water, 50 ml.</p>
            <p class="text_column">Eau de Parfum</p>
            <button onClick = {()=> setAddshop5Popup (true)}>Add Now</button>
            <Popup trigger = {addshop5Popup} setTrigger = {setAddshop5Popup}>
            <form>
                    <label>Product</label><br/>
                    <select><option>105</option></select><br/>
                    <label>Type</label><br/>
                    <select><option>Eau de Parfum</option></select><br/>
                    <label>Amount</label><br/>
                    <input type="text" placeholder="Amount"/><br/>
                    <label>Date</label><br/>
                    <input type="date" placeholder="Date"/><br/>
                    <button>Confirm</button>
                </form>
            </Popup>
          </div>
          <div class="thumbnail"> <a href="#"><img src="https://cf.shopee.co.th/file/409425ca18188b63e7df7b6f6fde26ff" alt="" width="2000" class="cards"/></a>
            <h4>pheromone perfume (106)</h4>
            <p class="tag">Perfume, pheromone perfume, attracting a gentle scent.</p>
            <p class="text_column">Eau de Toilette</p>
            <button onClick = {()=> setAddshop6Popup (true)}>Add Now</button>
            <Popup trigger = {addshop6Popup} setTrigger = {setAddshop6Popup}>
            <form>
                    <label>Product</label><br/>
                    <select><option>106</option></select><br/>
                    <label>Type</label><br/>
                    <select><option>Eau de Toilette</option></select><br/>
                    <label>Amount</label><br/>
                    <input type="text" placeholder="Amount"/><br/>
                    <label>Date</label><br/>
                    <input type="date" placeholder="Date"/><br/>
                    <button>Confirm</button>
                </form>
            </Popup>
          </div>
          <div class="thumbnail"> <a href="#"><img src="https://cf.shopee.co.th/file/1631701109d97f9435c4d2512938e1ee" alt="" width="2000" class="cards"/></a>
            <h4>SIVER 999 (107)</h4>
            <p class="tag">Perfume 999 vaporisateur natural spray 100ml.perfume-7123</p>
            <p class="text_column">Eau de Toilette</p>

            <button onClick = {()=> setAddshop7Popup (true)}>Add Now</button>
            <Popup trigger = {addshop7Popup} setTrigger = {setAddshop7Popup}>
            <form>
                    <label>Product</label><br/>
                    <select><option>107</option></select><br/>
                    <label>Type</label><br/>
                    <select><option>Eau de Toilette</option></select><br/>
                    <label>Amount</label><br/>
                    <input type="text" placeholder="Amount"/><br/>
                    <label>Date</label><br/>
                    <input type="date" placeholder="Date"/><br/>
                    <button>Confirm</button>
                </form>
            </Popup>

          </div>
        </div>
    </div>
    )
}

export default House
