import React from 'react'
import "./House.css"

function House() {
    return (
        <div class="contain"> 
            <header class="Warehouse">
            <h4 class="logo">WAREHOUSE</h4>
            </header>
            <section class="intro">
            <div class="column">
                <h3>PRODUCE ITEM</h3>
                <img src="https://cf.shopee.co.th/file/3e5db1422320f0ca3091256bd91656bb" alt="" class="profile"/> </div>
            <div class="column">
                <p>Buying a warehouse, we do not need permission or consent from anyone. If you want to change the warehouse, you can do it. </p>
                <p>To take advantage of their own assets Like a real estate investment And have the opportunity to add value over time When you want to expand your business You can use the assets here to apply for bank loans to invest in expanding your business.</p>
            </div>
        </section>
        <div class="gallery">
          <div class="thumbnail"> <a href="#"><img src="https://cf.shopee.co.th/file/1db74637819488c9f4be0d0803d6844a" alt="" width="2000" class="cards"/></a>
            <h4>PEACH OOLONG</h4>
            <p class="tag">M-808 perfume 80 ml. Available in 5 fragrances, fruity scents.</p>
            <p class="text_column">Eau de Parfum</p>
            <button>BUY NOW</button>
          </div>
          <div class="thumbnail"> <a href="#"><img src="https://cf.shopee.co.th/file/fa8bfa7072b553114dc38dee44bad277" alt="" width="2000" class="cards"/></a>
            <h4>Midnight</h4>
            <p class="tag">Midnight Fantasy Perfume Spray 35ml Suitable for teenagers.</p>
            <p class="text_column">Eau de Parfum</p>
            <button>BUY NOW</button>
          </div>
          <div class="thumbnail"> <a href="#"><img src="https://cf.shopee.co.th/file/dbe0b9212c05882dba3867e12875694b" alt="" width="2000" class="cards"/></a>
            <h4>Midnight Fantasy</h4>
            <p class="tag">The smell is also very popular evergreen available for teens ages.</p>
            <p class="text_column">Eau de Parfum</p>
            <button>BUY NOW</button>
          </div>
          <div class="thumbnail"> <a href="#"><img src="https://cf.shopee.co.th/file/2f47f4b3037899b20a650d908a76bcd3" alt="" width="2000" class="cards"/></a>
            <h4>Shimang</h4>
            <p class="tag">Shimang Long-lasting peach scent water, 50 ml.</p>
            <p class="text_column">Eau de Parfum.</p>
            <button>BUY NOW</button>
          </div>
        </div>
        <div class="gallery">
          <div class="thumbnail"> <a href="#"><img src="https://cf.shopee.co.th/file/35f091a9c34396d6e50b3832c3dc46b1" alt="" width="2000" class="cards"/></a>
            <h4>Shimang</h4>
            <p class="tag">Shimang Long-lasting peach scent water, 50 ml.</p>
            <p class="text_column">Eau de Parfum</p>
            <button>BUY NOW</button>
          </div>
          <div class="thumbnail"> <a href="#"><img src="https://cf.shopee.co.th/file/620de08772fe752680a2b35b4a038133" alt="" width="2000" class="cards"/></a>
            <h4>Shimang</h4>
            <p class="tag">Shimang Long-lasting peach scent water, 50 ml.</p>
            <p class="text_column">Eau de Parfum</p>
            <button>BUY NOW</button>
          </div>
          <div class="thumbnail"> <a href="#"><img src="https://cf.shopee.co.th/file/409425ca18188b63e7df7b6f6fde26ff" alt="" width="2000" class="cards"/></a>
            <h4>pheromone perfume</h4>
            <p class="tag">Perfume, pheromone perfume, attracting a gentle scent.</p>
            <p class="text_column">Eau de Toilette</p>
            <button>BUY NOW</button>
          </div>
          <div class="thumbnail"> <a href="#"><img src="https://cf.shopee.co.th/file/1631701109d97f9435c4d2512938e1ee" alt="" width="2000" class="cards"/></a>
            <h4>SIVER 999</h4>
            <p class="tag">Perfume 999 vaporisateur natural spray 100ml.perfume-7123</p>
            <p class="text_column">Eau de Toilette</p>
            <button>BUY NOW</button>
          </div>
        </div>
    </div>
    )
}

export default House
