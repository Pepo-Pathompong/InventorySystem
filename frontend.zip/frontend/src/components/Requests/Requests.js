import React from 'react'
import "./Requests.css"

function Requests() {
    return (
        <div class="request_area">
        <h1>Support Request</h1>
        <p>This form is a simple form.</p>
            <form>
                    <label>Your Name</label><br/>
                    <input type="text" placeholder="Your Name"/><br/>
                    <label>Your Email</label><br/>
                    <input type="email" placeholder="Your Email"/><br/>
                    <label>Phone Number</label><br/>
                    <input type="tel" placeholder="Phone Number"/><br/>
                    <label>Please describe your request</label><br/>
                    <textarea name="" id="" cols="30" rows="10" placeholder="You Message"></textarea><br/>
                    <label>File</label><br/>
                    <input type="file" placeholder="file"/><br/>
                <button>Submit</button>
            </form>
    </div>
    )
}

export default Requests
