import React from 'react'
import "./Leave.css"
import Popup from '../Popup/Popup'
import {useState} from 'react'
import axios from '../../axios'
import FormData from 'form-data'

function Leave() {
    const [viewPopup, setViewPopup] = useState(false);

    const [requester, setRequester] = useState("");
    const [description, setDescription] = useState("");
    const [start, setStart] = useState("");
    const [end, setEnd] = useState("");
    const [status, setStatus] = useState("");
    const [approver, setApprover] = useState("");

    const clickLeave = (event) => {
        event.preventDefault();
        const formData = new FormData();
        formData.append("requesterid", requester);
        formData.append("description", description);
        formData.append("start", start);
        formData.append("end", end);
        formData.append("status", status);
        formData.append("approverid", approver);
        console.log(requester,description,start,end,status,approver)
    
        axios.post("/LeaveServlet",formData).then((res) => {
          window.location.href = "/Apply";
        }).catch((error) =>{
          alert(error);
        });
      };

    return (
        <div class="Leave_area">
        <h1>New Leave Application</h1>
            <form>
                    <label>Requester</label><br/>
                    <input type="number"
                        value={requester}
                        onChange={(e) => setRequester(e.target.value)}
                        placeholder="Requester"
                        />
                    <br/>

                    <label>Description</label><br/>
                    <textarea type="text"
                        value={description}
                        onChange={(e) => setDescription(e.target.value)}
                        cols="30" rows="10" placeholder="Description">
                    </textarea>
                 <br/>

                    <label>Start</label><br/>
                    <input type="date"
                        value={start}
                        onChange={(e) => setStart(e.target.value)}
                        placeholder="Start"
                     />
                <br/>

                    <label>End</label><br/>
                    <input type="date"
                        value={end}
                        onChange={(e) => setEnd(e.target.value)}
                        placeholder="End"
                    />
                <br/>

                    <label>Status</label><br/>
                    <select type="text"
                        value={status}
                        onChange={(e) => setStatus(e.target.value)}
                        placeholder="Status">
                            <option>Status</option>
                         </select>
                     <br/>

                    <label>Approver</label><br/>
                    <input type="number"
                        value={approver}
                        onChange={(e) => setApprover(e.target.value)}
                        placeholder="Approver"
                    />
                 <br/>
                <button onClick ={clickLeave}>Submit</button> 
             </form><br/>
             <button onClick = {()=> setViewPopup (true)}>View</button>
            <Popup trigger = {viewPopup} setTrigger = {setViewPopup}>
            <table className="view">
                <thead>
                     <tr>
                        <th>Requester</th>
                        <th>Description</th>
                         <th>Start</th>
                        <th>End</th>
                        <th>Status</th>
                        <th>Approver</th>
                     </tr>
                 </thead>
            <tbody>
                <tr >
                    <td>Gabriella</td>
                    <td>Perfume, pheromone perfume, attracting a gentle scent.</td>
                    <td>24,000</td>
                    <td>35</td>  
                </tr>
                <tr class="active-row" >
                    <td>Elizabeth</td>
                    <td>Perfume, pheromone perfume, attracting a gentle scent.</td>
                    <td>35,000</td>
                    <td>50</td>
                </tr>
            </tbody>
         </table>
                </Popup>
    </div>
    )
}

export default Leave
