import React from 'react'
import "./Leave.css"

function Leave() {
    return (
        <div class="Leave_area">
        <h1>New Leave Application</h1>
            <form>
                    <label>Leave Type</label><br/>
                    <select><option>Employees</option></select><br/>
                    <label>From :</label><br/>
                    <input type="date" placeholder=""/><br/>
                    <label>To :</label><br/>
                    <input type="date" placeholder=""/><br/>
                    <label>Note</label><br/>
                    <input type="text" placeholder="Note"/><br/>
                    <label>Please describe your Leave</label><br/>
                    <textarea name="" id="" cols="30" rows="10" placeholder="You Message"></textarea><br/>
                    <label>Upload File</label><br/>
                    <input type="file" placeholder="file"/><br/>
                <button>Submit</button>
            </form>
    </div>
    )
}

export default Leave
