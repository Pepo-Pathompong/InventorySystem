import React from 'react'
import "./Payrolls.css"

function Payrolls() {
    return (
        <div class="Payrolls_area">
            <h1>Payroll System</h1>
            <form className = "Payrolls_loca">
                    <label>Full Name</label><br/>
                    <input type="text" placeholder="full name"/><br/>
                    <label>Hour/Day</label><br/>
                    <input type="number" placeholder="number"/><br/>
                    <label>Number of Days</label><br/>
                    <select>
                        <option>1</option><option>2</option><option>3</option>
                        <option>4</option><option>5</option><option>6</option>
                        <option>7</option><option>8</option><option>9</option>
                        <option>10</option><option>11</option><option>12</option>
                        <option>13</option><option>14</option><option>15</option>
                        <option>16</option><option>17</option><option>18</option>
                        <option>19</option><option>20</option><option>21</option>
                        <option>22</option><option>23</option><option>24</option>
                        <option>25</option><option>26</option><option>27</option>
                        <option>28</option><option>29</option><option>30</option>
                        <option>31</option>
                     </select>
                    <br/>
                    <label>Department</label><br/>
                    <input type="text" placeholder="Department"/><br/>
                    <label>Rate Per Day</label><br/>
                    <input type="text" placeholder="Rate"/><br/>
                    <label>Salary</label><br/>
                    <input type="text" placeholder="Salary"/><br/>
                <button type ="submit">Save</button><button type="reset">Reset</button>
            </form>
    </div>
    )
}

export default Payrolls
