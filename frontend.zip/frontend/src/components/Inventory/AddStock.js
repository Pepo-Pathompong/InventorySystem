import React from 'react'

function AddStock({info2}) {
    return (
        <>
              <tr>
                    <td>{info2.name}</td>
                    <td>{info2.description}</td>
                    <td>{info2.price}</td>
                    <td>{info2.amount}</td>  
                </tr>
        </>
    )
}

export default AddStock
