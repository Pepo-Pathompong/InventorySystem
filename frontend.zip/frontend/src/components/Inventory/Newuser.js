import React from 'react'

function Newuser({info}) {
    
    return (
        <>
             <tr>
                    <td>{info.firstname}</td>
                    <td>{info.lastname}</td>
                    <td>{info.gender}</td>
                    <td>{info.birthdate}</td>  
                </tr>
        </>
    )
}

export default Newuser
