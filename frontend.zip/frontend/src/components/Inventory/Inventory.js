import React,{useState,useEffect} from 'react'
import Popup from '../Popup/Popup'
import FormData from 'form-data'
import "./Inventory.css"
import axios from '../../axios';
import Newuser from './Newuser'
import qs from 'qs'
import AddStock from './AddStock';

function Inventory() {
    useEffect(() => {
        fetchStock()
        fetchUser()
    }, [])
    const fetchUser =()=>{
        axios.get("/UserServlet").then((e)=>{
            setNewuserPopup(e.data)
        }).catch((error) =>{
            alert(error);
          });
    }
    const fetchStock =()=>{
        axios.get("/StockServlet").then((e)=>{
            setAddstockPopup(e.data)
        }).catch((error) =>{
            alert(error);
          });
    }

    const [buttonPopup, setButtonPopup] = useState(false);
    const [newuserPopup, setNewuserPopup] = useState([]);
    const [addstockPopup, setAddstockPopup] = useState([]);

    const [name, setName] = useState([]);
    const [description, setDescription] = useState([]);
    const [price, setPrice] = useState([]);
    const [amount, setAmount] = useState([]);
    
    const clickStock = (event) => {
        event.preventDefault();
        // const formData = new FormData();
        // formData.append("name", name);
        // formData.append("description", description);
        // formData.append("price", price);
        // formData.append("amount", amount);
        // console.log(name,description,price,amount)
    
        axios.post("/StockServlet",qs.stringify({
            name,description,price,amount
          })).then((res) => {
            window.location.href = "/Inventorys";
          }).catch((error) =>{
            console.log(error)
            // alert(error.response.data.message);
          });
      
        };
    
    return (
        
        <div>
            <header>
            <h2>INVENTORY MANAGER</h2>
            </header>
         <table class="content-table" >
            <thead>
                <tr>
                    <th>Firstname</th>
                    <th>Lastname</th>
                    <th>Gender</th>
                    <th>Birthdate</th>
                </tr>
            </thead>
            <tbody>
               {newuserPopup.map((el)=>{
                   return(
                       <Newuser
                       key = {el.id}
                       info = {el}/>
                   )
               })}
            </tbody>
         </table>

         <header>
            <h2>STOCK PRODUCT</h2>
            </header>
            <button className="stock" onClick = {()=> setButtonPopup (true)}>STOCK</button>
            <Popup trigger = {buttonPopup} setTrigger = {setButtonPopup}>
            <form className ="stockPro ">
                    <label>Name</label><br/>
                    <input 
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Name"
                    /><br/>

                    <label>Description</label><br/>
                    <textarea 
                    type="text"
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Description"
                    cols="30" rows="10"></textarea><br/>

                    <label>Price</label><br/>
                    <input  type="text"
                    value={price}
                    onChange={(e) => setPrice(e.target.value)}
                    placeholder="Price"
                    /><br/>

                    <label>Amount</label><br/>
                    <input  type="text"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    placeholder="Amount"
                    /><br/>
                    <button onClick = {clickStock}>Confirm</button>
                </form>
            </Popup>
         <table class="content-table">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Description</th>
                    <th>Price</th>
                    <th>Amount</th>
                </tr>
            </thead>
            <tbody>
            {addstockPopup.map((el)=>{
                   return(
                       <AddStock
                       key = {el.id}
                       info2 = {el}/>
                   )
               })}
            </tbody>
         </table>

         <header>
            <h2>TRANSACTION</h2>
         </header>
         <table class="content-table">
            <thead>
                <tr>
                    <th>Product</th>
                    <th>Type</th>
                    <th>Amount</th>
                    <th>Date</th>
                    <th>UserID</th>
                </tr>
            </thead>
            <tbody>
                <tr >
                    <td>PEACH OOLONG (100)</td>
                    <td>Eau de Parfum</td>
                    <td>27</td>
                    <td>12/05/2021</td>  
                    <td>Anna</td>  
                </tr>
                <tr class="active-row" >
                    <td>Midnight (101)</td>
                    <td>Eau de Parfum</td>
                    <td>20</td>
                    <td>15/05/2021</td>  
                    <td>Gabriella</td>  
                </tr>
                <tr>
                    <td>Midnight Fantasy (102)</td>
                    <td>Eau de Parfum</td>
                    <td>12</td>
                    <td>18/05/2021</td>  
                    <td>April</td>  
                </tr>
                <tr>
                    <td>Shimang (103)</td>
                    <td>Eau de Parfum</td>
                    <td>20</td>
                    <td>22/05/2021</td>  
                    <td>Beatrice</td>  
                </tr>
            </tbody>
         </table>
        </div>
        
    )
}

export default Inventory
