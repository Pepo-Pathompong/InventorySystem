import React from 'react'
import "./CManage.css"

function CManage() {
    return (
     <div className = "CManager">
        <header class="header">
        <div class="container">
            <div class="header_area">
                <h1>Add a seductive, seductive charm with 10 sweet and refreshing fragrances!</h1>
                <p>Increase your confidence with a good perfume to charm yourself.</p>
            </div>
        </div>
    </header>
        
    <section class="info1">
        <div class="container">
            <div class="info1_area">
                <img src="https://backend.central.co.th/media/catalog/product/c/d/cds22809759-1.jpg?impolicy=resize" width ="300px" height = " 315" alt=""/>
                <div class="info1_text">
                    <h1> TOM FORD BEAUTY </h1>
                    <p>
                    Body oils from TOM FORD BEAUTY give your skin a radiant glow. With a seductive, sensual scent of citrus floral musk of Private Blend Soleil Neige.
                    </p>
                </div>
            </div>
        </div>
    </section>

    <section class="info2">
        <div class="container">
            <div class="info2_area">
                <div class="info2_text">
                    <h1> BVLGARI Aqva Pour Homme Atlantiqve </h1>
                    <p>Atlantic Ocean The ultimate symbol of infinite strength and power, the "Energizing Ocean accord" emphasizes the strong spirit of a man and the "Sea Amber Accord" reflects a deep, seductive calm.</p>
                </div>
                <img src="https://img.kingpowerclick.com/cdn-cgi/image/format=auto/kingpower-com/image/upload/w_640,h_640,f_auto/v1510832644/prod/717320-l1.jpg" width ="300px" height = " 310" alt=""/>
            </div>
        </div>
    </section>

    <section class="contact">
        <div class="container">
            <div class="contact_area">
                <h1>Please complete all fields</h1>
                <form>
                    <label>Your Name</label><br/>
                    <input type="text" placeholder="Your Name"/><br/>
                    <label>Your Email</label><br/>
                    <input type="email" placeholder="Your Email"/><br/>
                    <label>Job Title</label><br/>
                    <input type="text" placeholder="Job Title"/><br/>
                    <label>Birthdate</label><br/>
                    <input type="date" placeholder="Birthdate"/><br/>
                    <label>Phone Number</label><br/>
                    <input type="tel" placeholder="Phone Number"/><br/>
                    <label>Your Message</label><br/>
                    <textarea name="" id="" cols="30" rows="10" placeholder="You Message"></textarea><br/>
                    <button>Confirm</button>
                </form>
            </div>
        </div>
    </section>

</div>

    )
}

export default CManage
