import React from 'react'
import "./CManage.css"
import axios from '../../axios'
import FormData from 'form-data'
import {useState} from 'react'

function CManage() {
    const [firstname, setFirstname] = useState("");
    const [lastname, setLastname] = useState("");
    const [gender, setGender] = useState("");
    const [birthdate, setBirtdate] = useState("");

    const submitSignup = (event) => {
        event.preventDefault();
        const formData = new FormData();
        formData.append("firstname", firstname);
        formData.append("lastname", lastname);
        formData.append("gender", gender);
        formData.append("birthdate", birthdate);
        console.log(firstname,lastname,gender,birthdate)
    
        axios.post("/UpdateServlet",formData).then((res) => {
          window.location.href = "/Inventorys";
        }).catch((error) =>{
          alert(error);
        });
      };

    return (
     <div className = "CManager">
        <header class="header">
        <div class="container">
            <div class="header_area">
                <h1>Add a seductive, seductive charm with 10 sweet and refreshing fragrances!</h1>
                <p>Increase your confidence with a good perfume to charm yourself.</p>
            </div>
        </div>
    </header>
        
    <section class="info1">
        <div class="container">
            <div class="info1_area">
                <img src="https://backend.central.co.th/media/catalog/product/c/d/cds22809759-1.jpg?impolicy=resize" width ="300px" height = " 315" alt=""/>
                <div class="info1_text">
                    <h1> TOM FORD BEAUTY </h1>
                    <p>
                    Body oils from TOM FORD BEAUTY give your skin a radiant glow. With a seductive, sensual scent of citrus floral musk of Private Blend Soleil Neige.
                    </p>
                </div>
            </div>
        </div>
    </section>

    <section class="info2">
        <div class="container">
            <div class="info2_area">
                <div class="info2_text">
                    <h1> BVLGARI Aqva Pour Homme Atlantiqve </h1>
                    <p>Atlantic Ocean The ultimate symbol of infinite strength and power, the "Energizing Ocean accord" emphasizes the strong spirit of a man and the "Sea Amber Accord" reflects a deep, seductive calm.</p>
                </div>
                <img src="https://img.kingpowerclick.com/cdn-cgi/image/format=auto/kingpower-com/image/upload/w_640,h_640,f_auto/v1510832644/prod/717320-l1.jpg" width ="300px" height = " 310" alt=""/>
            </div>
        </div>
    </section>

    <section class="contact">
        <div class="container">
            <div class="contact_area">
                <h1>Please complete all fields</h1>
                <form>
                    <label>firstname</label><br/>
                    <input type="text"
                        value={firstname}
                        onChange={(e) => setFirstname(e.target.value)}
                        placeholder="Firstname"
                        />
                    <br/>

                    <label>lastname</label><br/>
                    <input type="text"
                        value={lastname}
                        onChange={(e) => setLastname(e.target.value)}
                        placeholder="Lastname"
                        />
                    <br/>

                    <label>gender</label><br/>
                    <input type="text"
                        value={gender}
                        onChange={(e) => setGender(e.target.value)}
                        placeholder="Gender"
                        />
                    <br/>

                    <label>birthdate</label><br/>
                    <input type="date"
                        value={birthdate}
                        onChange={(e) => setBirtdate(e.target.value)}
                        placeholder="Birthdate"
                        />
                    <br/>
                    <button onClick = {submitSignup}>Confirm</button>
                </form>
            </div>
        </div>
    </section>

</div>

    )
}

export default CManage
