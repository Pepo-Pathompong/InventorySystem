import React from "react";
import { BrowserRouter as Router,Switch,Route,Link} from "react-router-dom";
import Dashboard from "./Page/Dashboard"
import Company from "./Page/Company"
import Employee from "./Page/Employee"
import Warehouse from "./Page/Warehouse"
import Request from "./Page/Request"
import Apply from "./Page/Apply"
import Payroll from "./Page/Payroll"
import Register from "./Page/Register"
import LoginPage from "./components/Login/LoginPage";

function App  (){
  return (
   <Router>
     <Switch>

          <Route exact path="/">
                <LoginPage/>
            </Route >

            <Route exact path="/Register">
                <Register/>
            </Route >

            <Route path="/Dashboard">
                <Dashboard/>
            </Route >

            <Route path="/Company">
                <Company/>
            </Route >

            <Route path="/Employee">
                <Employee/>
            </Route >

            <Route path="/Warehouse">
                <Warehouse/>
            </Route >

            <Route path="/Request">
                <Request/>
            </Route >

            <Route path="/Apply">
                <Apply/>
            </Route >

            <Route path="/Payroll">
                <Payroll/>
            </Route >
     </Switch>
   </Router>
  )
}

export default App;
