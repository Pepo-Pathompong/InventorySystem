import React from "react";
import { BrowserRouter as Router,Switch,Route,Link} from "react-router-dom";
import Dashboard from "./Page/Dashboard"
import Company from "./Page/Company"
import Inventorys from "./Page/Inventorys"
import Warehouse from "./Page/Warehouse"
import Apply from "./Page/Apply"
import Register from "./Page/Register"
import LoginPage from "./components/Login/LoginPage";

function App  (){
  return (
   <Router>
     <Switch>

          <Route exact path="/">
                <LoginPage/>
            </Route >

            <Route  path="/Register">
                <Register/>
            </Route >

            <Route path="/Dashboard">
                <Dashboard/>
            </Route >

            <Route path="/Company">
                <Company/>
            </Route >

            <Route path="/Inventorys">
                <Inventorys/>
            </Route >

            <Route path="/Warehouse">
                <Warehouse/>
            </Route >

            <Route path="/Apply">
                <Apply/>
            </Route >

     </Switch>
   </Router>
  )
}

export default App;
